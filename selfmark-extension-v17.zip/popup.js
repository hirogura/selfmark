let serverUrl = '';
let bookmarks = [];
let categories = new Set();
let catOrder = [];
let starredOrder = [];
let itemOrder = {};
let faviconMode = -1;
// サーバ側の設定値（拡張からのPOSTで上書きしないよう保持する）
let serverFaviconMode = 0;
let serverCategories = [];
// 画像キャッシュバスター（更新・再読込ごとに再取得させる）
let iconCacheBuster = 0;

document.addEventListener('DOMContentLoaded', () => {
  loadSettings();
  setupEventListeners();
});

function setupEventListeners() {
  document.getElementById('logo-link').addEventListener('click', openServerConsole);
  document.getElementById('settings-btn').addEventListener('click', showSettings);
  document.getElementById('back-btn').addEventListener('click', hideSettings);
  document.getElementById('save-settings-btn').addEventListener('click', saveSettings);
  document.getElementById('add-btn').addEventListener('click', showSaveBar);
  document.getElementById('save-confirm-btn').addEventListener('click', saveBookmark);
  document.getElementById('save-cancel-btn').addEventListener('click', hideSaveBar);
  document.getElementById('refresh-btn').addEventListener('click', loadBookmarks);
  document.getElementById('reload-icons-btn').addEventListener('click', reloadIcons);
  document.getElementById('search-input').addEventListener('input', filterBookmarks);
  document.getElementById('favicon-mode').addEventListener('change', saveFaviconSetting);
}

function openServerConsole() {
  if (!serverUrl) { showSettings(); return; }
  chrome.tabs.create({ url: serverUrl });
}

function loadSettings() {
  chrome.storage.sync.get(['serverUrl', 'faviconMode'], (result) => {
    serverUrl = result.serverUrl || '';
    faviconMode = [-1, 0, 1, 2].includes(result.faviconMode) ? result.faviconMode : -1;
    document.getElementById('favicon-mode').value = faviconMode;
    if (serverUrl) {
      showMainView();
      loadBookmarks();
    } else {
      showSettings();
    }
  });
}

function saveFaviconSetting() {
  faviconMode = parseInt(document.getElementById('favicon-mode').value);
  chrome.storage.sync.set({ faviconMode });
  filterBookmarks();
}

function showSettings() {
  document.getElementById('main-view').classList.add('hidden');
  document.getElementById('settings-view').classList.remove('hidden');
  if (serverUrl) document.getElementById('server-url').value = serverUrl;
}

function hideSettings() {
  document.getElementById('settings-view').classList.add('hidden');
  document.getElementById('main-view').classList.remove('hidden');
}

function showMainView() {
  document.getElementById('settings-view').classList.add('hidden');
  document.getElementById('main-view').classList.remove('hidden');
}

function saveSettings() {
  const url = document.getElementById('server-url').value.trim().replace(/\/$/, '');
  if (!url) { showMessage('settings-msg', 'URLを入力してください', 'error'); return; }
  serverUrl = url;
  chrome.storage.sync.set({ serverUrl: url }, () => {
    showMessage('settings-msg', '保存しました', 'success');
    setTimeout(() => { hideSettings(); loadBookmarks(); }, 500);
  });
}

function showSaveBar() {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs[0]) {
      document.getElementById('save-name').value = tabs[0].title || '';
      document.getElementById('save-url').value = tabs[0].url || '';
      updateCategorySelect();
      document.getElementById('save-bar').classList.remove('hidden');
    }
  });
}

function hideSaveBar() {
  document.getElementById('save-bar').classList.add('hidden');
  document.getElementById('save-msg').classList.add('hidden');
}

function updateCategorySelect() {
  const select = document.getElementById('save-category');
  select.innerHTML = '<option value="">カテゴリーなし</option>';
  const allCats = [...categories];
  const sorted = catOrder.length > 0
    ? catOrder.filter(c => allCats.includes(c)).concat(allCats.filter(c => !catOrder.includes(c)))
    : allCats.sort((a, b) => a.localeCompare(b, 'ja'));
  sorted.forEach(cat => {
    const opt = document.createElement('option');
    opt.value = cat;
    opt.textContent = cat;
    select.appendChild(opt);
  });
}

function postBookmarksData() {
  // favicon_mode / categories はサーバ側の値を保持して送る（拡張操作でリセットしない）
  const cats = [...new Set([...serverCategories, ...bookmarks.map(s => s.category).filter(Boolean)])];
  return fetch(`${serverUrl}/api/bookmarks`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ bookmarks, cat_order: catOrder, starred_order: starredOrder, item_order: itemOrder, categories: cats, favicon_mode: serverFaviconMode }),
  }).then(r => r.json());
}

function saveBookmark() {
  const name = document.getElementById('save-name').value.trim();
  const url = document.getElementById('save-url').value.trim();
  const category = document.getElementById('save-category').value;
  if (!name || !url) { showMessage('save-msg', '名前とURLを入力してください', 'error'); return; }
  if (bookmarks.some(s => s.url === url)) { showMessage('save-msg', 'このURLは既に追加済みです', 'error'); return; }
  bookmarks.push({ name, url, category, starred: false });
  if (category && !catOrder.includes(category)) catOrder.push(category);
  if (category) categories.add(category);
  const key = category || '__none__';
  if (!itemOrder[key]) itemOrder[key] = [];
  itemOrder[key].push(url);
  postBookmarksData().then(() => {
    showMessage('save-msg', '保存しました', 'success');
    setTimeout(() => { hideSaveBar(); loadBookmarks(); }, 500);
  }).catch(() => { showMessage('save-msg', '保存に失敗しました', 'error'); });
}

async function loadBookmarks() {
  if (!serverUrl) return null;
  document.getElementById('bookmarks').innerHTML = '<div class="loading">読み込み中...</div>';
  try {
    const response = await fetch(`${serverUrl}/api/bookmarks`, { cache: 'no-store' });
    if (!response.ok) throw new Error('ブックマークの取得に失敗しました');
    const data = await response.json();
    bookmarks = data.bookmarks || [];
    catOrder = data.cat_order || [];
    starredOrder = data.starred_order || [];
    itemOrder = data.item_order || {};
    serverFaviconMode = data.favicon_mode || 0;
    serverCategories = data.categories || [];
    iconCacheBuster = Math.max(Date.now(), iconCacheBuster + 1);
    categories = new Set();
    bookmarks.forEach(s => { if (s.category) categories.add(s.category); });
    catOrder.forEach(c => categories.add(c));
    (data.categories || []).forEach(c => categories.add(c));
    return await filterBookmarks();
  } catch(e) {
    document.getElementById('bookmarks').innerHTML = '<div class="empty">接続に失敗しました</div>';
    return null;
  }
}

async function reloadIcons() {
  if (!serverUrl) {
    showMessage('settings-msg', '先にコンソールURLを保存してください', 'error');
    return;
  }
  const button = document.getElementById('reload-icons-btn');
  button.disabled = true;
  showMessage('settings-msg', 'アイコンを再取得しています…', 'success');
  try {
    const results = await loadBookmarks();
    if (results === null) {
      showMessage('settings-msg', 'サーバへの接続に失敗しました', 'error');
      return;
    }
    const failed = results.filter(ok => !ok).length;
    showMessage('settings-msg', results.length === 0
      ? '表示対象のアイコンがありません。ファビコン表示設定も確認してください。'
      : `再取得完了：表示 ${results.length - failed} 件 / 取得失敗 ${failed} 件`, failed ? 'error' : 'success');
  } finally {
    button.disabled = false;
  }
}

function applyItemOrder(items, key) {
  const order = itemOrder[key];
  if (!order || order.length === 0) return items;
  const found = order.map(url => items.find(s => s.url === url)).filter(Boolean);
  const rest = items.filter(s => !order.includes(s.url));
  return found.concat(rest);
}

function isSearchActive() {
  return document.getElementById('search-input').value.trim() !== '';
}

function filterBookmarks() {
  const query = document.getElementById('search-input').value.toLowerCase().trim();
  if (!query) {
    return renderBookmarks(bookmarks, false);
  }
  const titleMatches = bookmarks.filter(s => s.name.toLowerCase().includes(query));
  const urlMatches = bookmarks.filter(s =>
    !s.name.toLowerCase().includes(query) && s.url.toLowerCase().includes(query)
  );
  return renderBookmarks([...titleMatches, ...urlMatches], true);
}

function renderBookmarks(allBookmarks, filtering) {
  const container = document.getElementById('bookmarks');

  const starredAll = allBookmarks.filter(s => s.starred);
  const starred = starredOrder.length > 0
    ? starredOrder.map(url => starredAll.find(s => s.url === url)).filter(Boolean).concat(starredAll.filter(s => !starredOrder.includes(s.url)))
    : starredAll;

  const groups = {};
  const noCategory = [];
  allBookmarks.forEach(s => {
    if (s.category) {
      if (!groups[s.category]) groups[s.category] = [];
      groups[s.category].push(s);
    } else {
      noCategory.push(s);
    }
  });

  if (!filtering) {
    Object.keys(groups).forEach(cat => { groups[cat] = applyItemOrder(groups[cat], cat); });
  }
  const noCategorySorted = filtering ? noCategory : applyItemOrder(noCategory, '__none__');

  let html = '';

  if (filtering) {
    if (allBookmarks.length === 0) {
      html = '<div class="empty">一致するブックマークがありません</div>';
    } else {
      html = allBookmarks.map(s => renderBookmarkCard(s, s.starred)).join('');
    }
  } else {
    // お気に入り - 展開状態で表示
    if (starred.length > 0) {
      html += `<div class="star-section">
        <div class="star-header expanded" data-toggle="star">
          <span class="arrow" style="transform:rotate(90deg)">▶</span>
          ⭐ お気に入り
          <span style="margin-left:auto;font-size:11px;color:#ccc;">${starred.length}</span>
        </div>
        <div class="star-body" id="star-body" data-order-key="__starred__">
          ${starred.map(s => renderBookmarkCard(s, true)).join('')}
        </div>
      </div>`;
    }

    // カテゴリー - 折りたたみ状態で表示
    const allCatNames = [...new Set([...Object.keys(groups), ...categories])];
    const sortedCats = catOrder.length > 0
      ? catOrder.filter(c => allCatNames.includes(c)).concat(allCatNames.filter(c => !catOrder.includes(c)))
      : allCatNames.sort((a, b) => a.localeCompare(b, 'ja'));

    sortedCats.forEach((cat, catIdx) => {
      const catId = 'cat-' + catIdx;
      const items = groups[cat] || [];
      html += `<div class="category">
        <div class="category-header" data-toggle="${catId}">
          <span class="arrow">▶</span>
          📂 ${escapeHtml(cat)}
          <span style="margin-left:auto;font-size:11px;color:#ccc;">${items.length}</span>
        </div>
        <div class="category-body collapsed" id="${catId}" data-order-key="${encodeURIComponent(cat)}">
          ${items.map(s => renderBookmarkCard(s, false)).join('')}
        </div>
      </div>`;
    });

    // 未分類 - 折りたたみ状態で表示
    if (noCategorySorted.length > 0) {
      html += `<div class="category">
        <div class="category-header" data-toggle="cat-none">
          <span class="arrow">▶</span>
          📋 未分類
          <span style="margin-left:auto;font-size:11px;color:#ccc;">${noCategorySorted.length}</span>
        </div>
        <div class="category-body collapsed" id="cat-none" data-order-key="__none__">
          ${noCategorySorted.map(s => renderBookmarkCard(s, false)).join('')}
        </div>
      </div>`;
    }

    if (allBookmarks.length === 0 && [...categories].length === 0) {
      html = '<div class="empty">ブックマークがありません</div>';
    }
  }

  container.innerHTML = html;

  // トグルイベント
  if (!filtering) {
    container.querySelectorAll('[data-toggle]').forEach(header => {
      header.addEventListener('click', function() {
        const targetId = this.getAttribute('data-toggle');
        const body = targetId === 'star' ? document.getElementById('star-body') : document.getElementById(targetId);
        if (body) {
          body.classList.toggle('collapsed');
          this.classList.toggle('expanded');
          const arrow = this.querySelector('.arrow');
          if (arrow) {
            arrow.style.transform = this.classList.contains('expanded') ? 'rotate(90deg)' : '';
          }
        }
      });
    });
  }

  // ブックマーククリック
  container.querySelectorAll('.bookmark').forEach(card => {
    card.addEventListener('click', function(e) {
      if (e.target.closest('.star-btn') || e.target.closest('.edit-btn') || e.target.closest('.delete-btn') || e.target.closest('.bookmark-name-input')) return;
      const url = decodeURIComponent(this.getAttribute('data-url'));
      if (url) chrome.tabs.create({ url });
    });
  });

  // スターボタン
  container.querySelectorAll('.star-btn').forEach(btn => {
    btn.addEventListener('click', function(e) {
      e.preventDefault(); e.stopPropagation();
      toggleStar(decodeURIComponent(this.getAttribute('data-url')));
    });
  });

  // 編集ボタン
  container.querySelectorAll('.edit-btn').forEach(btn => {
    btn.addEventListener('click', function(e) {
      e.preventDefault(); e.stopPropagation();
      startEditName(decodeURIComponent(this.getAttribute('data-url')), this);
    });
  });

  // 削除ボタン
  container.querySelectorAll('.delete-btn').forEach(btn => {
    btn.addEventListener('click', function(e) {
      e.preventDefault(); e.stopPropagation();
      deleteBookmark(decodeURIComponent(this.getAttribute('data-url')));
    });
  });

  // ドラッグ&ドロップ
  if (!filtering) {
    setupDragAndDrop(container);
  }
  return Promise.all([...container.querySelectorAll('[data-icon-sources]')].map(loadBookmarkIcon));
}

let dragState = null;

function setupDragAndDrop(container) {
  container.querySelectorAll('.bookmark').forEach(card => {
    card.addEventListener('dragstart', function(e) {
      const body = this.closest('[data-order-key]');
      if (!body) { e.preventDefault(); return; }
      dragState = {
        card: this,
        url: decodeURIComponent(this.getAttribute('data-url')),
        orderKey: body.getAttribute('data-order-key'),
        body: body,
      };
      setTimeout(() => this.classList.add('dragging'), 0);
      e.dataTransfer.effectAllowed = 'move';
    });

    card.addEventListener('dragend', function() {
      this.classList.remove('dragging');
      container.querySelectorAll('.drag-over').forEach(el => el.classList.remove('drag-over'));
      dragState = null;
    });

    card.addEventListener('dragover', function(e) {
      if (!dragState || this === dragState.card) return;
      const body = this.closest('[data-order-key]');
      if (!body || body.getAttribute('data-order-key') !== dragState.orderKey) return;
      e.preventDefault();
      e.dataTransfer.dropEffect = 'move';
      container.querySelectorAll('.drag-over').forEach(el => el.classList.remove('drag-over'));
      this.classList.add('drag-over');
    });

    card.addEventListener('dragleave', function() {
      this.classList.remove('drag-over');
    });

    card.addEventListener('drop', function(e) {
      e.preventDefault();
      e.stopPropagation();
      this.classList.remove('drag-over');
      if (!dragState || this === dragState.card) return;
      const body = this.closest('[data-order-key]');
      if (!body || body.getAttribute('data-order-key') !== dragState.orderKey) return;

      const orderKeyRaw = dragState.orderKey;
      const draggedCard = dragState.card;
      const targetCard = this;
      const parent = body;

      parent.insertBefore(draggedCard, targetCard);

      const newUrls = [...parent.querySelectorAll('.bookmark')].map(el => decodeURIComponent(el.getAttribute('data-url')));
      const orderKey = (orderKeyRaw === '__starred__' || orderKeyRaw === '__none__')
        ? orderKeyRaw : decodeURIComponent(orderKeyRaw);

      if (orderKey === '__starred__') {
        starredOrder = newUrls;
      } else {
        itemOrder[orderKey] = newUrls;
      }

      postBookmarksData().catch(() => {});
    });
  });
}

function deleteBookmark(url) {
  if (!confirm('このブックマークを削除しますか？')) return;
  const bookmark = bookmarks.find(s => s.url === url);
  const key = bookmark && bookmark.category ? bookmark.category : '__none__';
  bookmarks = bookmarks.filter(s => s.url !== url);
  starredOrder = starredOrder.filter(u => u !== url);
  if (itemOrder[key]) itemOrder[key] = itemOrder[key].filter(u => u !== url);
  if (itemOrder['__starred__']) itemOrder['__starred__'] = itemOrder['__starred__'].filter(u => u !== url);
  postBookmarksData().then(() => loadBookmarks()).catch(() => loadBookmarks());
}

function startEditName(url, btnEl) {
  const card = btnEl.closest('.bookmark');
  if (!card) return;
  const nameEl = card.querySelector('.bookmark-name');
  if (!nameEl || card.querySelector('.bookmark-name-input')) return;
  const bookmark = bookmarks.find(s => s.url === url);
  if (!bookmark) return;

  const input = document.createElement('input');
  input.type = 'text';
  input.className = 'bookmark-name-input';
  input.value = bookmark.name;
  nameEl.replaceWith(input);
  card.setAttribute('draggable', 'false');
  input.focus();
  input.select();

  let committed = false;
  const commit = () => {
    if (committed) return;
    committed = true;
    const newName = input.value.trim();
    if (newName && newName !== bookmark.name) {
      bookmark.name = newName;
      postBookmarksData().then(() => loadBookmarks());
    } else {
      loadBookmarks();
    }
  };

  input.addEventListener('keydown', function(e) {
    if (e.key === 'Enter') { e.preventDefault(); commit(); }
    else if (e.key === 'Escape') { e.preventDefault(); committed = true; loadBookmarks(); }
  });
  input.addEventListener('blur', commit);
  input.addEventListener('click', e => e.stopPropagation());
}

function getIconSources(s) {
  const sources = [];
  if (s.icon) sources.push(`${serverUrl}/icon/${encodeURIComponent(s.icon)}?t=${iconCacheBuster}`);
  const mode = faviconMode === -1 ? serverFaviconMode : faviconMode;
  if (mode >= 1) {
    sources.push(`${serverUrl}/api/favicon?url=${encodeURIComponent(s.url)}&t=${iconCacheBuster}`);
  }
  if (mode === 2) {
    try {
      const url = new URL(s.url);
      if (['http:', 'https:'].includes(url.protocol)) {
        ['ico', 'png', 'svg'].forEach(ext => sources.push(`${url.origin}/favicon.${ext}?t=${iconCacheBuster}`));
      }
    } catch(e) {}
  }
  return sources;
}

function getIconHtml(s) {
  const sources = getIconSources(s);
  const fallback = '<div class="bookmark-icon">&#128204;</div>';
  if (!sources.length) return fallback;
  return `<img class="bookmark-favicon" style="display:none" data-icon-sources="${encodeURIComponent(JSON.stringify(sources))}" alt="">${fallback}`;
}

function loadBookmarkIcon(img) {
  const sources = JSON.parse(decodeURIComponent(img.dataset.iconSources));
  return new Promise(resolve => {
    let index = 0;
    let timer;
    const finish = ok => {
      clearTimeout(timer);
      img.removeEventListener('load', loaded);
      img.removeEventListener('error', next);
      img.style.display = ok ? '' : 'none';
      img.nextElementSibling.style.display = ok ? 'none' : 'flex';
      resolve(ok);
    };
    const loaded = () => finish(true);
    const next = () => {
      clearTimeout(timer);
      if (index >= sources.length) {
        img.removeAttribute('src');
        finish(false);
        return;
      }
      timer = setTimeout(next, 20000);
      img.src = sources[index++];
    };
    img.addEventListener('load', loaded);
    img.addEventListener('error', next);
    next();
  });
}

function renderBookmarkCard(s, isStarred) {
  let hostname = '', origin = '';
  try {
    const u = new URL(s.url);
    hostname = u.port ? `${u.hostname}:${u.port}` : u.hostname;
    origin = u.origin;
  }
  catch(e) { hostname = s.url; }
  const starClass = isStarred ? 'on' : '';
  const starIcon = isStarred ? '★' : '☆';
  const encodedUrl = encodeURIComponent(s.url);

  let iconHtml = getIconHtml(s);

  return `<div class="bookmark" draggable="true" data-url="${encodedUrl}">
    ${iconHtml}
    <div class="bookmark-info">
      <div class="bookmark-name">${escapeHtml(s.name)}</div>
      <div class="bookmark-url">${escapeHtml(hostname)}</div>
    </div>
    <button class="edit-btn" data-url="${encodedUrl}" title="名前を編集">✎</button>
    <button class="delete-btn" data-url="${encodedUrl}" title="削除">🗑</button>
    <button class="star-btn ${starClass}" data-url="${encodedUrl}" title="お気に入り">${starIcon}</button>
  </div>`;
}

function toggleStar(url) {
  const bookmark = bookmarks.find(s => s.url === url);
  if (!bookmark) return;
  bookmark.starred = !bookmark.starred;
  if (bookmark.starred) {
    if (!starredOrder.includes(url)) starredOrder.push(url);
  } else {
    starredOrder = starredOrder.filter(u => u !== url);
  }
  postBookmarksData().then(() => filterBookmarks()).catch(() => {
    bookmark.starred = !bookmark.starred;
  });
}

function showMessage(id, msg, type) {
  const el = document.getElementById(id);
  el.textContent = msg;
  el.className = `message ${type}`;
  el.classList.remove('hidden');
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}
